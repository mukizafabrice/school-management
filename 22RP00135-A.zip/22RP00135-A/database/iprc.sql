-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2024 at 12:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iprc`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `regNumber` varchar(20) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `module` varchar(20) NOT NULL,
  `TotalHours` int(11) NOT NULL,
  `type` enum('true','false') NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `regNumber`, `FirstName`, `LastName`, `module`, `TotalHours`, `type`) VALUES
(1, '22RP00135', 'John', 'Doe', 'PHP', 40, 'true'),
(2, '22RP00354', 'Jane', 'Smith', 'PHP', 35, 'true'),
(3, '22RP00123', 'Michael', 'Johnson', 'PHP', 32, 'true'),
(4, '22RP00155', 'Emily', 'Williams', 'PHP', 38, 'true'),
(5, '22RP00156', 'Christopher', 'Brown', 'PHP', 31, 'true'),
(6, '22RP00157', 'Amanda', 'Jones', 'PHP', 37, 'true'),
(7, '22RP00158', 'David', 'Garcia', 'PHP', 34, 'true'),
(8, '22RP00159', 'Jessica', 'Martinez', 'PHP', 36, 'true'),
(9, '22RP00160', 'Matthew', 'Hernandez', 'PHP', 33, 'true'),
(10, '22RP00161', 'Jennifer', 'Young', 'PHP', 39, 'true'),
(11, '22RP00162', 'Daniel', 'King', 'PHP', 41, 'true'),
(12, '22RP00163', 'Ashley', 'Lee', 'PHP', 37, 'true'),
(13, '22RP00164', 'Christopher', 'Scott', 'PHP', 32, 'true'),
(14, '22RP00103', 'Sarah', 'Gonzalez', 'PHP', 38, 'true'),
(15, '22RP00166', 'Robert', 'Walker', 'PHP', 35, 'true'),
(16, '22RP00167', 'Melissa', 'Hill', 'PHP', 33, 'true'),
(17, '22RP00168', 'James', 'Allen', 'PHP', 40, 'true'),
(18, '22RP00169', 'Laura', 'Wright', 'PHP', 36, 'true'),
(19, '22RP00170', 'Brian', 'Scott', 'PHP', 31, 'true'),
(20, '22RP00171', 'Stephanie', 'Lopez', 'PHP', 37, 'true'),
(21, '22RP00172', 'Joshua', 'Green', 'PHP', 34, 'true'),
(22, '22RP00173', 'Lauren', 'Adams', 'PHP', 39, 'true'),
(23, '22RP00174', 'William', 'Baker', 'PHP', 35, 'true'),
(24, '22RP00175', 'Danielle', 'Rivera', 'PHP', 36, 'true'),
(25, '22RP00176', 'Kevin', 'Carter', 'PHP', 33, 'true'),
(26, '22RP00177', 'Hannah', 'Mitchell', 'PHP', 41, 'true'),
(27, '22RP00178', 'Justin', 'Thompson', 'PHP', 38, 'true'),
(28, '22RP00179', 'Eric', 'Perez', 'PHP', 32, 'true'),
(29, '22RP00180', 'Megan', 'Ross', 'PHP', 37, 'true'),
(30, '22RP00181', 'Brandon', 'Campbell', 'PHP', 34, 'true'),
(31, '22RP00135', 'John', 'Doe', 'BUSINESS', 40, 'true'),
(32, '22RP00354', 'Jane', 'Smith', 'BUSINESS', 35, 'true'),
(33, '22RP00123', 'Michael', 'Johnson', 'BUSINESS', 32, 'true'),
(34, '22RP00155', 'Emily', 'Williams', 'BUSINESS', 38, 'true'),
(35, '22RP00156', 'Christopher', 'Brown', 'BUSINESS', 31, 'true'),
(36, '22RP00157', 'Amanda', 'Jones', 'BUSINESS', 37, 'true'),
(37, '22RP00158', 'David', 'Garcia', 'BUSINESS', 34, 'true'),
(38, '22RP00159', 'Jessica', 'Martinez', 'BUSINESS', 36, 'true'),
(39, '22RP00160', 'Matthew', 'Hernandez', 'BUSINESS', 33, 'true'),
(40, '22RP00161', 'Jennifer', 'Young', 'BUSINESS', 39, 'true'),
(41, '22RP00162', 'Daniel', 'King', 'BUSINESS', 41, 'true'),
(42, '22RP00163', 'Ashley', 'Lee', 'BUSINESS', 37, 'true'),
(43, '22RP00164', 'Christopher', 'Scott', 'BUSINESS', 32, 'true'),
(44, '22RP00103', 'Sarah', 'Gonzalez', 'BUSINESS', 38, 'true'),
(45, '22RP00166', 'Robert', 'Walker', 'BUSINESS', 35, 'true'),
(46, '22RP00167', 'Melissa', 'Hill', 'BUSINESS', 33, 'true'),
(47, '22RP00168', 'James', 'Allen', 'BUSINESS', 40, 'true'),
(48, '22RP00169', 'Laura', 'Wright', 'BUSINESS', 36, 'true'),
(49, '22RP00170', 'Brian', 'Scott', 'BUSINESS', 31, 'true'),
(50, '22RP00171', 'Stephanie', 'Lopez', 'BUSINESS', 37, 'true'),
(51, '22RP00172', 'Joshua', 'Green', 'BUSINESS', 34, 'true'),
(52, '22RP00173', 'Lauren', 'Adams', 'BUSINESS', 39, 'true'),
(53, '22RP00174', 'William', 'Baker', 'BUSINESS', 35, 'true'),
(54, '22RP00175', 'Danielle', 'Rivera', 'BUSINESS', 36, 'true'),
(55, '22RP00176', 'Kevin', 'Carter', 'BUSINESS', 33, 'true'),
(56, '22RP00177', 'Hannah', 'Mitchell', 'BUSINESS', 41, 'true'),
(57, '22RP00178', 'Justin', 'Thompson', 'BUSINESS', 38, 'true'),
(58, '22RP00179', 'Eric', 'Perez', 'BUSINESS', 32, 'true'),
(59, '22RP00180', 'Megan', 'Ross', 'BUSINESS', 37, 'true'),
(60, '22RP00181', 'Brandon', 'Campbell', 'BUSINESS', 34, 'true'),
(61, '', '', '', '', 0, 'false'),
(62, '22RP00135', 'John', 'Doe', 'JAVA', 40, 'false'),
(63, '22RP00354', 'Jane', 'Smith', 'JAVA', 35, 'false'),
(64, '22RP00123', 'Michael', 'Johnson', 'JAVA', 32, 'false'),
(65, '22RP00155', 'Emily', 'Williams', 'JAVA', 38, 'false'),
(66, '22RP00156', 'Christopher', 'Brown', 'JAVA', 31, 'false'),
(67, '22RP00157', 'Amanda', 'Jones', 'JAVA', 37, 'false'),
(68, '22RP00158', 'David', 'Garcia', 'JAVA', 34, 'false'),
(69, '22RP00159', 'Jessica', 'Martinez', 'JAVA', 36, 'false'),
(70, '22RP00160', 'Matthew', 'Hernandez', 'JAVA', 33, 'false'),
(71, '22RP00161', 'Jennifer', 'Young', 'JAVA', 39, 'false'),
(72, '22RP00162', 'Daniel', 'King', 'JAVA', 41, 'false'),
(73, '22RP00163', 'Ashley', 'Lee', 'JAVA', 37, 'false'),
(74, '22RP00164', 'Christopher', 'Scott', 'JAVA', 32, 'false'),
(75, '22RP00103', 'Sarah', 'Gonzalez', 'JAVA', 38, 'false'),
(76, '22RP00166', 'Robert', 'Walker', 'JAVA', 35, 'false'),
(77, '22RP00167', 'Melissa', 'Hill', 'JAVA', 33, 'false'),
(78, '22RP00168', 'James', 'Allen', 'JAVA', 40, 'false'),
(79, '22RP00169', 'Laura', 'Wright', 'JAVA', 36, 'false'),
(80, '22RP00170', 'Brian', 'Scott', 'JAVA', 31, 'false'),
(81, '22RP00171', 'Stephanie', 'Lopez', 'JAVA', 37, 'false'),
(82, '22RP00172', 'Joshua', 'Green', 'JAVA', 34, 'false'),
(83, '22RP00173', 'Lauren', 'Adams', 'JAVA', 39, 'false'),
(84, '22RP00174', 'William', 'Baker', 'JAVA', 35, 'false'),
(85, '22RP00175', 'Danielle', 'Rivera', 'JAVA', 36, 'false'),
(86, '22RP00176', 'Kevin', 'Carter', 'JAVA', 33, 'false'),
(87, '22RP00177', 'Hannah', 'Mitchell', 'JAVA', 41, 'false'),
(88, '22RP00178', 'Justin', 'Thompson', 'JAVA', 38, 'false'),
(89, '22RP00179', 'Eric', 'Perez', 'JAVA', 32, 'false'),
(90, '22RP00180', 'Megan', 'Ross', 'JAVA', 37, 'false'),
(91, '22RP00181', 'Brandon', 'Campbell', 'JAVA', 34, 'false');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL,
  `regNumber` varchar(20) NOT NULL DEFAULT 'staff',
  `role` enum('student','trainer','director') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `FirstName`, `LastName`, `email`, `password`, `regNumber`, `role`) VALUES
(1, 'Ernest ', 'Uwizeye', 'ernest@gmail.com', '$2y$10$KSJuyIDODQ74li.5.Tntge/Ox5TgW7FbAXvI61mK8QKlisrzvdUbe', 'PHP', 'trainer'),
(3, 'Kelly', 'Mao', 'kelly@gmail.com', '$2y$10$MidNZMkOr7TUtSaIGZn3y.yqHyjk7HKrgzu1RI1odv2AtMiTVukkG', 'DIRECTOR', 'director'),
(4, 'Uwamahoro', 'Bonavanture', 'bona@gmail.com', '$2y$10$M3IwJgDI.XFDkdYW/c1gNO6rJSC9oQSGHHAVXXJST5ywX0h3Vl3ay', 'JAVA', 'trainer'),
(5, 'Michael', 'Johnson', 'michael@gmail.com', '$2y$10$4em1.7np2P2voKTi.xqXcOs4XWVj5y7bIFFY7Lrb5YfYCWlHUzZeW', '22RP00123', 'student'),
(6, 'Sarah', 'Gonzalez', 'sarah@gmail.com', '$2y$10$xBndjA5xL6Ht3kZ9YnBPDO3mZ4nhQ2Ta.bJnna9rozWVpsrH/HSTq', '22RP00103', 'student'),
(7, 'Emily', 'Williams', 'emily@gmail.com', '$2y$10$S0Jo9Wqot.dBNadMJKb18.MKXlCj1YBEiauwHdeshvhRzjiQu034W', '22RP00155', 'student'),
(8, 'John', 'Doe', 'john@gmail.com', '$2y$10$dQpl39QxACHoCjx9ceB3iO0WRxmu8pdVkRMpxxjpzGkNVWMkE3dh.', '22RP00135', 'student'),
(9, 'Claire', 'Ineza', 'claire@gmail.com', '$2y$10$nJhg6mwEKdPrn4xrawtBq.Gxa7qV63uHcGNVEiL6xGcY1eEFgnTgG', 'BUSINESS', 'trainer'),
(10, 'Christopher', 'Brown', 'christopher@gmail.com', '$2y$10$fioFFze2LoeFbdUwKDX72uCqfXmULy9EycVe/mfcf43W5MCLstSmy', '2RP00156', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
